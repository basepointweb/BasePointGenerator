﻿namespace $safeprojectname$.Shared
{
    public static class SharedConstants
    {
        public static class ErrorMessages
        {
            public static readonly string PropertyIsInvalid = "001;The property '{0}' is invalid.";
        }
    }
}